/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import static practica_02_procesos.Practica_02_Procesos.colaProceso;
import static practica_02_procesos.Practica_02_Procesos.ram;

/**
 *
 * @author shens
 */
public class Menu extends JFrame implements ActionListener {

    private final JLabel label1;
    private final JLabel label2;
    private final JLabel label3;
    private final JButton boton1;
    private final JButton boton2;
    private final JButton boton3;
    private final JButton boton4;
    private final JButton boton5;
    private final JButton boton6;
    private final JButton boton7;
    private final JButton boton8;
    private final JButton boton9;
    private final JButton boton10;
    private Float porcentaje;

    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 20);

    public Menu() {
        setLayout(null);
        setTitle("Menu");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        label1 = new JLabel("Process Simulator", SwingConstants.LEFT);
        label1.setBounds(30, 10, 300, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0, 0, 0));
        add(label1);

        label2 = new JLabel("memoria:", SwingConstants.LEFT);
        label2.setBounds(30, 420, 100, 30);
        label2.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label2.setForeground(new Color(0, 0, 0));
        add(label2);
        porcentaje = (float) practica_02_procesos.Practica_02_Procesos.ram.espaciosDisponible;
        label3 = new JLabel(String.valueOf((int) (porcentaje / 1024 * 100)) + "%", SwingConstants.CENTER);
        label3.setBounds(100, 420, 300, 30);
        label3.setFont(font1);
        label3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label3.setForeground(new Color(0, 240, 0));
        add(label3);

        boton1 = new JButton("Crear proceso");
        boton1.setBounds(30, 100, 440, 22);
        boton1.setFont(font1);
        boton1.setBackground(Color.white);
        add(boton1);
        boton1.addActionListener(this);

        boton2 = new JButton("Ver estado de los procesos");
        boton2.setBounds(30, 132, 440, 22);
        boton2.setFont(font1);
        boton2.setBackground(Color.white);
        add(boton2);
        boton2.addActionListener(this);
        
        boton9 = new JButton("Ver estado de la memoria");
        boton9.setBounds(30, 164, 440, 22);
        boton9.setFont(font1);
        boton9.setBackground(Color.white);
        add(boton9);
        boton9.addActionListener(this);
        

        boton3 = new JButton("Imprimir cola de procesos");
        boton3.setBounds(30, 196, 440, 22);
        boton3.setFont(font1);
        boton3.setBackground(Color.white);
        add(boton3);
        boton3.addActionListener(this);

        boton4 = new JButton("Ejecutar proceso actual");
        boton4.setBounds(30, 228, 440, 22);
        boton4.setFont(font1);
        boton4.setBackground(Color.white);
        add(boton4);
        boton4.addActionListener(this);

        boton5 = new JButton("Ver proceso actual");
        boton5.setBounds(30, 260, 440, 22);
        boton5.setFont(font1);
        boton5.setBackground(Color.white);
        add(boton5);
        boton5.addActionListener(this);

        boton6 = new JButton("Pasar al proceso siguiente");
        boton6.setBounds(30, 293, 440, 22);
        boton6.setFont(font1);
        boton6.setBackground(Color.white);
        add(boton6);
        boton6.addActionListener(this);

        boton7 = new JButton("Matar proceso actual");
        boton7.setBounds(30, 324, 440, 22);
        boton7.setFont(font1);
        boton7.setBackground(Color.white);
        add(boton7);
        boton7.addActionListener(this);

        boton8 = new JButton("Matar todo y terminar");
        boton8.setBounds(30, 356, 440, 22);
        boton8.setFont(font1);
        boton8.setBackground(Color.white);
        add(boton8);
        boton8.addActionListener(this);
        
        boton10 = new JButton("Desfragmentar memoria");
        boton10.setBounds(30, 388, 440, 22);
        boton10.setFont(font1);
        boton10.setBackground(Color.white);
        add(boton10);
        boton10.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            CrearProceso c1 = new CrearProceso();
            this.setVisible(false);
            c1.setBounds(0, 0, 500, 500);
            c1.setLocationRelativeTo(null);
            c1.setResizable(false);
            c1.setVisible(true);
        }
        if (e.getSource() == boton2) {
            VerEstadoActualDelSistema v1 = new VerEstadoActualDelSistema();
            this.setVisible(false);
            v1.setBounds(0, 0, 680, 600);
            v1.setLocationRelativeTo(null);
            v1.setResizable(false);
            v1.setVisible(true);
        }
        if (e.getSource() == boton9) {
            VerEstadoDeLaMemoria i1 = new VerEstadoDeLaMemoria();
            this.setVisible(false);
            i1.setBounds(0, 0, 500, 500);
            i1.setLocationRelativeTo(null);
            i1.setResizable(false);
            i1.setVisible(true);
        }
        if (e.getSource() == boton3) {
            ImprimirColaDeProcesos i1 = new ImprimirColaDeProcesos();
            this.setVisible(false);
            i1.setBounds(0, 0, 500, 500);
            i1.setLocationRelativeTo(null);
            i1.setResizable(false);
            i1.setVisible(true);
        }
        if (e.getSource() == boton4) {
            if (colaProceso.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay procesos listos");

            } else {
                EjecutarProcesoActual e1 = new EjecutarProcesoActual();
                this.setVisible(false);
                e1.setBounds(0, 0, 500, 500);
                e1.setLocationRelativeTo(null);
                e1.setResizable(false);
                e1.setVisible(true);
            }

        }
        if (e.getSource() == boton5) {
            if (colaProceso.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay procesos listos");

            } else {
                VerProcesoActual e1 = new VerProcesoActual();
                this.setVisible(false);
                e1.setBounds(0, 0, 500, 500);
                e1.setLocationRelativeTo(null);
                e1.setResizable(false);
                e1.setVisible(true);
            }
        }
        if (e.getSource() == boton6) {
            if (colaProceso.size()<2) {
                JOptionPane.showMessageDialog(null, "No hay un segundo proceso");

            } else {
               PasaAlProcesoSiguiente e1 = new PasaAlProcesoSiguiente();
                this.setVisible(false);
                e1.setBounds(0, 0, 500, 500);
                e1.setLocationRelativeTo(null);
                e1.setResizable(false);
                e1.setVisible(true);
            }
        }
        if (e.getSource() == boton7) {
            if (colaProceso.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay procesos para eliminar");

            } else {
                MataProcesoActual e1 = new MataProcesoActual();
                this.setVisible(false);
                e1.setBounds(0, 0, 500, 500);
                e1.setLocationRelativeTo(null);
                e1.setResizable(false);
                e1.setVisible(true);
            }
        }
        if (e.getSource() == boton8) {
             if (colaProceso.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay procesos para eliminar");
                System.exit(0);

            } else {
                MatarTodoYTerminar e1 = new MatarTodoYTerminar();
                this.setVisible(false);
                e1.setBounds(0, 0, 500, 500);
                e1.setLocationRelativeTo(null);
                e1.setResizable(false);
                e1.setVisible(true);
                
            }
        }
        if (e.getSource() == boton10) {
            DesfragmentarMemoria i1 = new DesfragmentarMemoria();
            this.setVisible(false);
            i1.setBounds(0, 0, 500, 500);
            i1.setLocationRelativeTo(null);
            i1.setResizable(false);
            i1.setVisible(true);
        }

    }

}
