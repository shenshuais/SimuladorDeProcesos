/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author shens
 */
public class DesfragmentarMemoria extends JFrame implements ActionListener{
    private final JLabel label1;
    private final JButton boton1;
    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 80);
    
    public DesfragmentarMemoria(){
        setLayout(null);
        setTitle("Desfragmentar Memoria");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        
        label1 = new JLabel("Desfragmentar Memoria", SwingConstants.LEFT);
        label1.setBounds(30, 10, 600, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0, 0, 0));
        add(label1);

        boton1 = new JButton("si");
        boton1.setBounds(100, 100, 300, 200);
        boton1.setFont(font1);
        boton1.setForeground(Color.white);
        boton1.setBackground(Color.ORANGE);
        add(boton1);
        boton1.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            Practica_02_Procesos.desfragmentacion();
            JOptionPane.showMessageDialog(null, "Operacion Existosa");
            this.setVisible(false);
            Menu m1 = new Menu();
            m1.setBounds(0, 0, 500, 500);
            m1.setLocationRelativeTo(null);
            m1.setResizable(false);
            m1.setVisible(true);
        }
    }
    
}
