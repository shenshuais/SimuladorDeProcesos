package practica_02_procesos;

import java.util.ArrayList;
import java.util.Scanner;

public class Practica_02_Procesos {

    public static ArrayList<Proceso> colaProceso = new ArrayList();
    public static ArrayList<Proceso> procesoFinalizado = new ArrayList();
    public static ArrayList<Proceso> procesoEliminado = new ArrayList();
    public static Memoria ram = new Memoria();

    public static void main(String[] args) {
        int retorno = 0;
        while (retorno == 0) {
            System.out.println("BIENVENIDO A SU SIMULADOR DE PROCESOS");
            System.out.println("\t\tLocalidades Disponibles: " + ram.espaciosDisponible);
            System.out.println("MENU:");
            System.out.println("1)Crear proceso\n2)Ver estado actual del sistema\n3)Imprimir cola de procesos\n4)Ejecutar cola de procesos\n5)Ver proceso actual\n6)Pasar al proceso siguiente\n7)Matar proceso actual\n8)Matar todo y terminar");
            Scanner opcion = new Scanner(System.in);
            int opcion1 = opcion.nextInt();
            if (opcion1 <= 8 && opcion1 >= 1) {

                switch (opcion1) {
                    case 1:
                        Proceso proceso = new Proceso();
                        if (ram.guardaProceso(proceso)) {
                            colaProceso.add(proceso);
                        } else {
                            System.out.println("Memoria Insuficiente: ya que el proceso creado anteriomente pesa " + proceso.getMemorySpace() + " localidades y restan: " + ram.espaciosDisponible);
                        }

                        break;
                    case 2:
                        verEstadoActual();
                        break;
                    case 3:
                        System.out.println("Tabla de procesos preparados para su ejecucion");
                        System.out.println("El proceso activo es el proceso #1");
                        imprimirColaDeProcesos(colaProceso);
                        break;
                    case 4:
                        ejecutarProcesoActual();
                        break;
                    case 5:
                        System.out.println("5");
                        break;
                    case 6:
                        System.out.println("6");
                        break;
                    case 7:
                        ram.imprimirMemoria();
                        break;
                    case 8:
                        System.out.println("8");
                        retorno = 1;
                        break;
                    default:
                        System.out.println("Opcion invalida");
                        break;

                }

            }
        }

    }

    public static void imprimirColaDeProcesos(ArrayList<Proceso> listaProceso) {
        for (int i = 0; i < listaProceso.size(); i++) {
            System.out.print((i + 1) + ")Nombre: " + listaProceso.get(i).getNameProcess() + "\tid: " + listaProceso.get(i).getIdProcess());
            System.out.print("\t#instrucciones: " + listaProceso.get(i).getNumInstruccion() + "\tMemoria usada: " + listaProceso.get(i).getMemorySpace());
            System.out.println("\n\n");

        }

    }

    public static void verEstadoActual() {
        System.out.println("El numero de procesos listos: " + colaProceso.size());
        System.out.println("listas de procesos finalizados exitosamente");
        for (int i = 0; i < procesoFinalizado.size(); i++) {
            System.out.println((i + 1) + ")" + procesoFinalizado.get(i).getNameProcess());
        }
        System.out.println("Lista de procesos Eliminados");
        imprimirColaDeProcesos(procesoEliminado);
        for (int i = 0; i < colaProceso.size(); i++) {
            ArrayList<Integer> listaAux = new ArrayList();
            System.out.print("Nombre: " + colaProceso.get(i).getNameProcess());
            for (int j = 0; j < ram.espaciosTotal; j++) {
                if (colaProceso.get(i).getIdProcess() == ram.memoryMatriz[j][1]) {
                    listaAux.add(ram.memoryMatriz[j][0]);
                }
            }
            System.out.println("\nLocalidades ocupadas: ");
            System.out.println(listaAux);
        }
    }
    public static void ejecutarProcesoActual() {
        if(colaProceso.get(0).getNumInstruccion()>=5){
            /*eliminar 5 instrucciones y ponerlo a final de colaProcesos*/
            Proceso procesoAux = colaProceso.get(0);
            procesoAux.setNumInstruccion(procesoAux.getNumInstruccion()-5);
            colaProceso.add(procesoAux);
            colaProceso.remove(0);
            System.out.println("El proceso: "+colaProceso.get(0).getNameProcess()+" ha ejecutado exitosamente");
            
        }else{
            /*agregarlo a cola de finlizados y eliminarlo de la memoria*/
            System.out.println("El proceso: "+colaProceso.get(0).getNameProcess()+" ha finalizado exitosamente");
            procesoFinalizado.add(colaProceso.get(0));
            ram.eliminarProceso(colaProceso.get(0));
            colaProceso.remove(0);
            
        }
    }

}
