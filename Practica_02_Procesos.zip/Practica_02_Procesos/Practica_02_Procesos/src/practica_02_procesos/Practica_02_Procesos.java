package practica_02_procesos;

import java.util.ArrayList;
import java.util.Scanner;

public class Practica_02_Procesos {

    public static ArrayList<Proceso> colaProceso = new ArrayList();
    public static ArrayList<Proceso> procesoFinalizado = new ArrayList();
    public static ArrayList<Proceso> procesoEliminado = new ArrayList();
    public static Memoria ram = new Memoria();

    public static void main(String[] args) {
        InterfaceBienVenida f1 = new InterfaceBienVenida();
        f1.setBounds(0, 0, 500, 500);
        f1.setLocationRelativeTo(null);
        f1.setResizable(false);
        f1.setVisible(true);
        int retorno = 0;
        while (retorno == 0) {
            System.out.println("BIENVENIDO A SU SIMULADOR DE PROCESOS");
            System.out.println("\t\tLocalidades Disponibles: " + ram.espaciosDisponible);
            System.out.println("MENU:");
            System.out.println("1)Crear proceso\n2)Ver estado de los procesos\n3)Ver Estado de la memoria\n4)Imprimir cola de procesos\n5)Ejecutar proceso actual\n6)Ver proceso actual\n7)Pasar al proceso siguiente\n8)Matar proceso actual\n9)Matar todo y terminar\n10)Desfragmentar memoria");
            Scanner opcion = new Scanner(System.in);
            int opcion1 = opcion.nextInt();
            if (opcion1 <= 10 && opcion1 >= 1) {

                switch (opcion1) {
                    case 1:
                        //tuve que modificar aqui para pasar el texto
                        System.out.println("Ingresar el nombre de proceso:");
                        Scanner texto = new Scanner(System.in);
                        String nombre = texto.next();
                        Proceso proceso = new Proceso(nombre);
                        if (ram.guardaProceso(proceso)) {
                            colaProceso.add(proceso);
                        } else {
                            System.out.println("Memoria Insuficiente: ya que el proceso creado anteriomente pesa " + proceso.getMemorySpace() + " localidades y restan: " + ram.espaciosDisponible);
                        }

                        break;
                    case 2:
                        verEstadoActual();
                        break;
                    case 3:
                        ram.hacerListaLigada();
                        ram.imprimirListaLigada();
                        break;
                    case 4:
                        System.out.println("Tabla de procesos preparados para su ejecucion");
                        System.out.println("El proceso activo es el proceso #1");
                        imprimirColaDeProcesos(colaProceso);
                        break;
                    case 5:
                        ejecutarProcesoActual();
                        break;
                    case 6:
                        verProcesoActual();
                        break;
                    case 7:
                        nextProcess();
                        break;
                    case 8:
                        matarProcesoActual();
                        break;
                    case 9:
                        matarTodoTerminar();
                        retorno = 1;
                        break;
                    case 10:
                        desfragmentacion();
                        break;
                    default:
                        System.out.println("Opcion invalida");
                        break;

                }

            }
        }

    }

    public static void desfragmentacion() {
        if (ram.espaciosDisponible != 1024 && ram.espaciosDisponible != 0) {
            //recorrer registro de paginas
            int registroPaginasAux[][] = new int[64][2];
            for (int i = 0; i < 64; i++) {
                registroPaginasAux[i][0] = i + 1;
            }
            for (int i = 0; i < 64; i++) {
                if (ram.registroPaginas[i][1] != 0) {
                    for (int j = 0; j < 64; j++) {
                        if (registroPaginasAux[j][1] == 0) {
                            registroPaginasAux[j][1] = ram.registroPaginas[i][1];
                            break;
                        }
                    }
                }
            }
            ram.registroPaginas = registroPaginasAux;
            // recorrer localidades de memoria          0, 1-15   1, 
            ram.eliminarMemoria();
            int i = 0;
            while (ram.registroPaginas[i][1] != 0) {
                int idAux = ram.registroPaginas[i][1];
                for(int j=i*15+i; j<=(i*15+i)+15; j++){
                    ram.memoryMatriz[j][1]=idAux;
                }
                i++;
            }
            // modificando tabla de paginas de cada proceso 
            for(i=0; i<colaProceso.size(); i++){
                int idAux=colaProceso.get(i).getIdProcess();
                ArrayList<Integer> direccionFisica = new ArrayList();
                for(int j=0; j<64; j++){
                    if(idAux==ram.registroPaginas[j][1]){
                        direccionFisica.add(j);
                    }
                }
                for(int j=0; j<colaProceso.get(i).getPaginas(); j++){
                    colaProceso.get(i).tablaPagina[j][1]=direccionFisica.get(j);
                }
            }

        }else{
            System.out.println("No hay procesos en la memoria");
        }

    }

    public static void imprimirColaDeProcesos(ArrayList<Proceso> listaProceso) {
        for (int i = 0; i < listaProceso.size(); i++) {
            System.out.print((i + 1) + ")Nombre: " + listaProceso.get(i).getNameProcess() + "\tid: " + listaProceso.get(i).getIdProcess());
            System.out.print("\t#instrucciones: " + listaProceso.get(i).getNumInstruccion() + "\tMemoria usada: " + listaProceso.get(i).getMemorySpace());
            System.out.println("\n\n");

        }

    }

    public static void verEstadoActual() {
        System.out.println("El numero de procesos listos: " + colaProceso.size());
        System.out.println("listas de procesos finalizados exitosamente");
        for (int i = 0; i < procesoFinalizado.size(); i++) {
            System.out.println((i + 1) + ")" + procesoFinalizado.get(i).getNameProcess());
        }
        System.out.println("Lista de procesos Eliminados");
        imprimirColaDeProcesos(procesoEliminado);
        for (int i = 0; i < colaProceso.size(); i++) {
            ArrayList<Integer> listaAux = new ArrayList();
            System.out.print("Nombre: " + colaProceso.get(i).getNameProcess());
            for (int j = 0; j < ram.espaciosTotal; j++) {
                if (colaProceso.get(i).getIdProcess() == ram.memoryMatriz[j][1]) {
                    listaAux.add(ram.memoryMatriz[j][0]);
                }
            }
            System.out.println("\nLocalidades ocupadas: ");
            System.out.println(listaAux);
        }
    }

    public static void ejecutarProcesoActual() {
        if (colaProceso.size() == 0) {
            System.out.println("No hay procesos listos");
        } else {
            if (colaProceso.get(0).getNumInstruccion() >= 5) {
                //eliminar 5 instrucciones y ponerlo a final de colaProcesos
                System.out.println("El proceso: " + colaProceso.get(0).getNameProcess() + " ha ejecutado exitosamente");
                Proceso procesoAux = colaProceso.get(0);
                procesoAux.setNumInstruccion(procesoAux.getNumInstruccion() - 5);
                colaProceso.add(procesoAux);
                colaProceso.remove(0);

            } else {
                //agregarlo a cola de finlizados y eliminarlo de la memoria
                System.out.println("El proceso: " + colaProceso.get(0).getNameProcess() + " ha finalizado exitosamente");
                procesoFinalizado.add(colaProceso.get(0));
                ram.eliminarProceso(colaProceso.get(0));
                colaProceso.remove(0);

            }
        }

    }

    public static void verProcesoActual() {
        if (colaProceso.size() == 0) {
            System.out.println("No hay procesos listos");
        } else {
            System.out.println("Proceso actual ");
            System.out.print("Nombre: " + colaProceso.get(0).getNameProcess());
            System.out.print("  Id: " + colaProceso.get(0).getIdProcess());
            System.out.print("  Instrucciones totales: " + colaProceso.get(0).getNumInstruccionTotal());
            System.out.print("  Instrucciones ejecutadas: " + (colaProceso.get(0).getNumInstruccionTotal() - colaProceso.get(0).getNumInstruccion()));
            ArrayList<Integer> listaAux = new ArrayList();
            for (int j = 0; j < ram.espaciosTotal; j++) {
                if (colaProceso.get(0).getIdProcess() == ram.memoryMatriz[j][1]) {
                    listaAux.add(ram.memoryMatriz[j][0]);
                }
            }
            System.out.println("\nLocalidades ocupadas: ");
            System.out.println(listaAux);

            System.out.println("Ver Tabla de paginas");
            colaProceso.get(0).imprimirTablaPagina();
        }

    }

    public static void nextProcess() {
        if (colaProceso.size() < 2) {
            System.out.println("NO hay un segundo proceso");

        } else {
            Proceso procesoAux = colaProceso.get(0);
            colaProceso.add(procesoAux);
            colaProceso.remove(0);
            System.out.println("Operacion existosa");
        }

    }

    public static void matarProcesoActual() {
        if (colaProceso.isEmpty()) {
            System.out.println("NO hay proceso para eliminar");

        } else {
            procesoEliminado.add(colaProceso.get(0));
            ram.eliminarProceso(colaProceso.get(0));
            System.out.println("Se ha eliminado existosamente el proceso con nombre: " + colaProceso.get(0).getNameProcess());
            System.out.println("Instrucciones pendientes: " + colaProceso.get(0).getNumInstruccion());
            colaProceso.remove(0);
        }

    }

    public static void matarTodoTerminar() {
        if (colaProceso.isEmpty()) {
            System.out.println("NO hay proceso para eliminar");

        } else {
            System.out.println("Procesos eliminados: ");
            for (int i = 0; i < colaProceso.size(); i++) {
                System.out.print((i + 1) + ")Nombre: " + colaProceso.get(i).getNameProcess() + "\tid: " + colaProceso.get(i).getIdProcess());
                System.out.print("\t#instrucciones: " + colaProceso.get(i).getNumInstruccion() + "\tMemoria usada: " + colaProceso.get(i).getMemorySpace());

                ArrayList<Integer> listaAux = new ArrayList();
                for (int j = 0; j < ram.espaciosTotal; j++) {
                    if (colaProceso.get(i).getIdProcess() == ram.memoryMatriz[j][1]) {
                        listaAux.add(ram.memoryMatriz[j][0]);
                    }
                }
                System.out.println("\nLocalidades que utilizaban: ");
                System.out.println(listaAux);
            }
            for (int k = 0; k < colaProceso.size(); k++) {
                Proceso procesoAux = colaProceso.get(k);
                procesoEliminado.add(procesoAux);
                ram.eliminarProceso(procesoAux);
                colaProceso.remove(k);
            }
        }

    }

}
