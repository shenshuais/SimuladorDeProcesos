package practica_02_procesos;

import java.util.ArrayList;
import java.util.Scanner;

public class Practica_02_Procesos {

    public static ArrayList<Proceso> colaProceso = new ArrayList();
    public static Memoria ram = new Memoria();

    public static void main(String[] args) {
        int retorno = 0;
        while (retorno == 0) {
            System.out.println("BIENVENIDO A SU SIMULADOR DE PROCESOS");
            System.out.println("\t\tLocalidades Disponibles: "+ram.espaciosDisponible);
            System.out.println("MENU:");
            System.out.println("1)Crear proceso\n2)Ver estado actual del sistema\n3)Imprimir cola de procesos\n4)Ejecutar cola de procesos\n5)Ver proceso actual\n6)Pasar al proceso siguiente\n7)Matar proceso actual\n8)Matar todo y terminar");
            Scanner opcion = new Scanner(System.in);
            int opcion1 = opcion.nextInt();
            if (opcion1 <= 8 && opcion1 >= 1) {

                switch (opcion1) {
                    case 1:
                        /* FALTA EL METODO PARA VERIFICAR LA MEMORIA DISPONIBLE */
                        Proceso proceso = new Proceso();
                        if(ram.guardaProceso(proceso)){
                            colaProceso.add(proceso);
                        }else{
                            System.out.println("Memoria Insuficiente: ya que el proceso creado anteriomente pesa "+proceso.getMemorySpace()+" localidades y restan: "+ram.espaciosDisponible);
                        }
                        
                        break;
                    case 2:
                        
                        break;
                    case 3:
                        imprimirColaDeProcesos();
                        break;
                    case 4:
                        System.out.println("4");
                        break;
                    case 5:
                        System.out.println("5");
                        break;
                    case 6:
                        System.out.println("6");
                        break;
                    case 7:
                        System.out.println("7");
                        break;
                    case 8:
                        System.out.println("8");
                        retorno=1;
                        break;
                    default:
                        System.out.println("Opcion invalida");
                        break;

                }

            }
        }

    }
    
    public static void imprimirColaDeProcesos(){
        System.out.println("Tabla de procesos");
        for(int i=0; i<colaProceso.size(); i++){
            if(i==0){
                System.out.print((i+1)+") PROCESO ACTIVO Nombre: "+colaProceso.get(i).getNameProcess()+"\tid: "+colaProceso.get(i).getIdProcess());
                System.out.print("\t#instrucciones: "+colaProceso.get(i).getNumInstruccion()+"\tMemoria usada: "+colaProceso.get(i).getMemorySpace());
                System.out.println("\n\n");
            }
            else{
                System.out.print((i+1)+") Nombre: "+colaProceso.get(i).getNameProcess()+"\tid: "+colaProceso.get(i).getIdProcess());
                System.out.print("\t#instrucciones: "+colaProceso.get(i).getNumInstruccion()+"\tMemoria usada: "+colaProceso.get(i).getMemorySpace());
                System.out.println("\n\n");
            }
            
        }
        
    }

}
