/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;

/**
 *
 * @author shens
 */
public class Elemento {
    String elemento[] = new String[3];
    
    public Elemento(boolean poh, int i, int conta){
        if(poh){
            elemento[0]="P";
        }else{
            elemento[0]="H";
        }
        if(i==1023){
            elemento[1]=String.valueOf((i+1)-conta);
        }else{
            elemento[1]=String.valueOf(i-conta);
        }
        elemento[2]=String.valueOf(conta);
        
    }
}
