/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import static practica_02_procesos.Practica_02_Procesos.colaProceso;
import static practica_02_procesos.Practica_02_Procesos.ram;
/**
 *
 * @author shens
 */
public class CrearProceso extends JFrame implements ActionListener{
    private final JLabel label1;
    private final JLabel label2;
    private final JButton boton1;
    private final JTextField text1;
    private String text;
    
    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 20);
    
    public CrearProceso(){
        setLayout(null);
        setTitle("Crear Proceso");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        
        label1 = new JLabel("Crear Proceso", SwingConstants.LEFT);
        label1.setBounds(30, 10, 300, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0,0,0));
        add(label1);
        
        label2 = new JLabel("nombre:", SwingConstants.LEFT);
        label2.setBounds(30, 100, 100, 30);
        label2.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label2.setForeground(new Color(0,0,0));
        add(label2);
        
        text1 = new JTextField();
        text1.setBounds(100, 100, 200, 30);
        add(text1);
        
        boton1 = new JButton("Finalizar");
        boton1.setBounds(350, 400, 100, 30);
        boton1.setFont(font1);
        boton1.setBackground(Color.white);
        add(boton1);
        boton1.addActionListener(this);
        
    }
     @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==boton1){
                text=text1.getText();
                Proceso proceso = new Proceso(text);
                        if (ram.guardaProceso(proceso)) {
                            colaProceso.add(proceso);
                            JOptionPane.showMessageDialog(null, "El proceso se creo exitosamente");
                        } else {
                            JOptionPane.showMessageDialog(null, "Memoria Insuficiente: ya que el proceso creado anteriomente pesa " + proceso.getMemorySpace() + " localidades y restan: " + ram.espaciosDisponible);
                        }
                this.setVisible(false);
                Menu m1= new Menu();
                m1.setBounds(0, 0, 500, 500);
                m1.setLocationRelativeTo(null);
                m1.setResizable(false);
                m1.setVisible(true);
                        
            }
        }
    
}
