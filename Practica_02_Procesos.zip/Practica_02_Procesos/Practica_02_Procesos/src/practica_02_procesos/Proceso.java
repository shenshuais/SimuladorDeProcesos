package practica_02_procesos;

import java.util.ArrayList;
import java.util.Scanner;

public class Proceso {
    
    /* ---  INICIO ATRIBUTOS ---*/

    private String nameProcess;
    private int idProcess;
    private int numInstruc;
    private int numInstrucTotal;
    private int memorySpace; 
    private final int[] arrayIdProcess = new int[100];
    
    /* --- GETTERS --- */
    public Proceso(){
        CrearNombre();
        creacionID();
        creacionNumInstrucciones(); 
    }

    public String getNameProcess() {
        return nameProcess;
    }

    public int getIdProcess() {
        return idProcess;
    }
    
    public int getNumInstruccion() {
        return numInstruc;
    }
    
    public int getMemorySpace() {
        return memorySpace;
    }
    
    
    /* --- SETTERS --- */
    public void setNumInstruccion(int num){
        this.numInstruc=num;
    }


    
    /* INICIO DE METODOS */
    

    /* FALTA EL METODO PARA VERIFICAR LA MEMORIA DISPONIBLE */
    
    /* --- CREAR NOMBRE DEL PROCESO  ---*/
    private void CrearNombre() {
        System.out.println("Ingrese el nombre del proceso");
        Scanner nameProces = new Scanner(System.in);
        nameProcess = nameProces.next();

    }

    private void creacionID() {

        if (Practica_02_Procesos.colaProceso.isEmpty()) {

            idProcess = 1;

        } else {

            /*PRIMER FOR PARA RECORRER LA LISTA DE LA COLA*/
            for (int i = 0; i < Practica_02_Procesos.colaProceso.size(); i++) {
                
                
                arrayIdProcess[Practica_02_Procesos.colaProceso.get(i).idProcess] = 1;
                
            }
            for (int i=1; i<100 ; i++){
                
                if(arrayIdProcess[i]==0){
                    idProcess = i;
                    break; 
                }
            }
        }

    }
    /* Colaproceso: id:1                      ArrayIdProcess: 0 1 0 0 0 0 0 */
    
    /* --- METODO PARA DEFINIR EL NUMERO DE INSTRUCCIONES QUE TENDRA EL PROCESO --- */
    
    private void creacionNumInstrucciones(){
        
        int N = 30;
        int M = 10;
        /* Crear un numero aleatorio entero entre 30 (N) y 10 (M) */
        numInstruc = (int) Math.floor(Math.random()*(N-M+1)+M);
        numInstrucTotal=numInstruc;
        if(numInstruc > 9 && numInstruc < 15){
            memorySpace = 32;
            
        }
        else if(numInstruc > 14 && numInstruc < 19){
            memorySpace = 64;
            
        }
        else if (numInstruc > 18 && numInstruc < 24){
            memorySpace = 128;
            
        }
        else if(numInstruc > 23 && numInstruc < 28){
            memorySpace = 256;
            
        }else{
            memorySpace = 512;
           
        }
        
    }
    

}
