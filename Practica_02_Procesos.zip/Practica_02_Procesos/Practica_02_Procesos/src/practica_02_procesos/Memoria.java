package practica_02_procesos;

public class Memoria {

    /*Creacion de una matriz para la memoria*/
    int memoryMatriz[][] = new int[2048][2];
    int espaciosDisponible=2048;
    int espaciosTotal=2048;

    public Memoria() {
        nombrarLocalidades();
    }

    /*Metodos*/
    private void nombrarLocalidades() {
        for (int i = 0; i < 2048; i++) {
            memoryMatriz[i][0] = i + 1;
        }
    }

    public boolean guardaProceso(Proceso process) {
        if (espaciosDisponible >= process.getMemorySpace()) {

            /*escribe el id de proceso en las localidades disponibles*/
            for (int j = 0; j < process.getMemorySpace(); j++) {
                for (int i = 0; i < 2048; i++) {
                    if (memoryMatriz[i][1] == 0) {
                        memoryMatriz[i][1]=process.getIdProcess();
                        break;
                    }
                }

            }
            espaciosDisponible=espaciosDisponible-process.getMemorySpace();
            return true;

        }else{
            return false;
        }

    }
    public void eliminarProceso(Proceso process){
        for(int i=0; i<espaciosTotal; i++){
            if(Practica_02_Procesos.ram.memoryMatriz[i][1]==process.getIdProcess()){
               Practica_02_Procesos.ram.memoryMatriz[i][1]=0;
            }
            
        }
        espaciosDisponible=espaciosDisponible+process.getMemorySpace();
    }
    public void imprimirMemoria(){
        for(int i=0; i<2048; i++){
            for(int j=0; j<2; j++){
                System.out.print(" "+memoryMatriz[i][j]);
            }
            System.out.print("\n");
        }
        /*00 01
          10 11
          20 21*/
    }
}
