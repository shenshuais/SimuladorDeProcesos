package practica_02_procesos;

import java.util.ArrayList;
import java.util.Arrays;

public class Memoria {

    /*Creacion de una matriz para la memoria*/
    int memoryMatriz[][] = new int[1024][2];    
    int espaciosDisponible=1024;
    int espaciosTotal=1024;
    int paginasTotal=64;
    int paginasOcupadas=0;
    int paginasLibres=64;
    int registroPaginas[][]=new int[64][2];
    ArrayList<Elemento> listaLigada = new ArrayList();
    

    public Memoria() {
        nombrarLocalidades();
        nombrarPaginas();
    }

    /*Metodos*/
    private void nombrarLocalidades() {
        for (int i = 0; i < 1024; i++) {
            memoryMatriz[i][0] = i + 1;
        }
    }
    private void nombrarPaginas() {
        for (int i = 0; i < 64; i++) {
            registroPaginas[i][0] = i + 1;
        }
    }

    public boolean guardaProceso(Proceso process) {
        if (espaciosDisponible >= process.getMemorySpace()&& paginasLibres>=process.getPaginas()) {
            /*escribe el id de proceso en las localidades disponibles*/
            for (int j = 0; j < process.getPaginas(); j++) {
                for (int i = 0; i < 64; i++) {
                    if (registroPaginas[i][1] == 0) {
                        process.tablaPagina[j][0]=j;
                        process.tablaPagina[j][1]=i;
                        registroPaginas[i][1]=process.getIdProcess();
                        int localidadAux=i*15+i;
                        for(int k=localidadAux; k<localidadAux+16; k++ ){
                            memoryMatriz[k][1]=process.getIdProcess();
                        }
                        break;
                    }
                }

            }
           /* for (int j = 0; j < process.getMemorySpace(); j++) {
                for (int i = 0; i < 2048; i++) {
                    if (memoryMatriz[i][1] == 0) {
                        memoryMatriz[i][1]=process.getIdProcess();
                        break;
                    }
                }

            }*/
            espaciosDisponible=espaciosDisponible-process.getMemorySpace();
            paginasOcupadas=paginasOcupadas+process.getPaginas();
            paginasLibres=paginasLibres-process.getPaginas();
            return true;

        }else{
            return false;
        }

    }
    public void eliminarProceso(Proceso process){
        for(int j=0; j<process.getPaginas(); j++){
            registroPaginas[process.tablaPagina[j][1]][1]=0;
        }
        for(int i=0; i<espaciosTotal; i++){
            if(Practica_02_Procesos.ram.memoryMatriz[i][1]==process.getIdProcess()){
               Practica_02_Procesos.ram.memoryMatriz[i][1]=0;
            }
            
        }
        for(int i=0; i<process.getPaginas(); i++){
            process.tablaPagina[i][1]=0;
        }
        espaciosDisponible=espaciosDisponible+process.getMemorySpace();
        paginasOcupadas=paginasOcupadas-process.getPaginas();
        paginasLibres=paginasLibres+process.getPaginas();
    }
    public void eliminarMemoria(){
        for(int i=0; i<espaciosTotal; i++){
            Practica_02_Procesos.ram.memoryMatriz[i][1]=0;
        }
    }
    public void imprimirMemoria(){
        for(int i=0; i<1024; i++){
            for(int j=0; j<2; j++){
                System.out.print(" "+memoryMatriz[i][j]);
            }
            System.out.print("\n");
        }
        /*00 01
          10 11
          20 21*/
    }
    public void imprimirPaginas(){
        for(int i=0; i<64; i++){
            for(int j=0; j<2; j++){
                System.out.print(" "+registroPaginas[i][j]);
            }
            System.out.print("\n");
        }
    }
    public void hacerListaLigada(){
        Practica_02_Procesos.ram.listaLigada.clear();
        boolean poh=true;  //proceso o hueco
        int conta=0;
        int estado=Practica_02_Procesos.ram.memoryMatriz[0][1];
        for(int i=0; i<1024; i++){
            if(estado==Practica_02_Procesos.ram.memoryMatriz[i][1] && i!=1023){
               if(estado!=0){   // 800 = 0,    1023 = 0; 
                  poh=true;
               }else{
                  poh=false;
               }
               conta++;
            }else{
               if(i==1023){
                   conta++;
               }
               Elemento elemento= new Elemento(poh, i, conta);
               Practica_02_Procesos.ram.listaLigada.add(elemento);
               conta=1;
               estado=Practica_02_Procesos.ram.memoryMatriz[i][1]; 
            }
        }
    }
    public void imprimirListaLigada(){
        Elemento elementoAux;
        for(int i=0; i<Practica_02_Procesos.ram.listaLigada.size(); i++){
            elementoAux=Practica_02_Procesos.ram.listaLigada.get(i);
            System.out.println(" "+elementoAux.elemento[0]+" "+elementoAux.elemento[1]+" "+elementoAux.elemento[2]);
            
        }
    }
}
