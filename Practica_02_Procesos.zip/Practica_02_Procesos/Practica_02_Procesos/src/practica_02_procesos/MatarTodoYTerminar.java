/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import static practica_02_procesos.Practica_02_Procesos.colaProceso;
import static practica_02_procesos.Practica_02_Procesos.procesoEliminado;
import static practica_02_procesos.Practica_02_Procesos.procesoFinalizado;
import static practica_02_procesos.Practica_02_Procesos.ram;

/**
 *
 * @author shens
 */
public class MatarTodoYTerminar extends JFrame implements ActionListener {

    private final JLabel label1;
    private final JButton boton1;
    private final JTextArea ta1;
    private final JScrollPane ts1;
    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 20);

    public MatarTodoYTerminar() {
        setLayout(null);
        setTitle("Matar Todo Y Terminar");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);

        label1 = new JLabel("Matar Todo Y Terminar", SwingConstants.LEFT);
        label1.setBounds(30, 10, 600, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0, 0, 0));
        add(label1);

        ta1 = new JTextArea();
        ts1 = new JScrollPane(ta1);
        ts1.setBounds(30, 100, 440, 250);
        add(ts1);

        String texto1 = "";
        for (int i = 0; i < colaProceso.size(); i++) {
            texto1 = texto1 + String.valueOf(i + 1) + ")Nombre: " + colaProceso.get(i).getNameProcess() + "\tid: " + String.valueOf(colaProceso.get(i).getIdProcess()) + "\t#instrucciones: " + String.valueOf(colaProceso.get(i).getNumInstruccion()) + "\tMemoria usada: " + String.valueOf(colaProceso.get(i).getMemorySpace()) + "\n";
            texto1 = texto1 + "Memoria que utilizaba: ";
            for (int j = 0; j < ram.espaciosTotal; j++) {
                if (colaProceso.get(i).getIdProcess() == ram.memoryMatriz[j][1]) {
                    texto1 = texto1 + String.valueOf(ram.memoryMatriz[j][0] + "  ");
                }
            }
            texto1 = texto1 + "\n";

        }
        ta1.setText(texto1);

        boton1 = new JButton("Finalizar");
        boton1.setBounds(350, 400, 100, 30);
        boton1.setFont(font1);
        boton1.setBackground(Color.white);
        add(boton1);
        boton1.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            for (int k = 0; k < colaProceso.size(); k++) {
                Proceso procesoAux = colaProceso.get(k);
                procesoEliminado.add(procesoAux);
                ram.eliminarProceso(procesoAux);
                colaProceso.remove(k);
            }
            this.setVisible(false);
            System.exit(0);

        }
    }

}
