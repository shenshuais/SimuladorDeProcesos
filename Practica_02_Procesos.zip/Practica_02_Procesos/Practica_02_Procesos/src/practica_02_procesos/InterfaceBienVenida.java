/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author shens
 */
public class InterfaceBienVenida extends JFrame implements ActionListener{
    private final JLabel label1;
    private final JLabel label2;
    private final JLabel label3;
    private final JLabel label4;
    private final JButton boton1;
    
    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 20);
    
    
    public InterfaceBienVenida(){
        setLayout(null);
        setTitle("Bienvenido");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        label1 = new JLabel("Process Simulator", SwingConstants.CENTER);
        label1.setBounds(100, 10, 300, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0,0,0));
        add(label1);
        
        label2 = new JLabel("Sistemas Operativos", SwingConstants.CENTER);
        label2.setBounds(175, 120, 150, 30);
        //label2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label2.setFont(font1);
        label2.setForeground(new Color(0,0,0));
        add(label2);
        
        label3 = new JLabel("Semestre 2021-2", SwingConstants.CENTER);
        label3.setBounds(175, 180, 150, 30);
        //label3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label3.setFont(font1);
        label3.setForeground(new Color(0,0,0));
        add(label3);
        
        label4 = new JLabel("<html><body>Nombres:<br>Meza Arguello Luiz Fernando<br>Shen Shaui</body></html>", SwingConstants.LEFT);
        label4.setBounds(100, 240, 300, 80);
        label4.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label4.setFont(font1);
        label4.setForeground(new Color(0,0,0));
        add(label4);
        
        boton1 = new JButton("Ingresar");
        boton1.setBounds(200, 350, 100, 30);
        boton1.setFont(font1);
        boton1.setBackground(Color.white);
        add(boton1);
        boton1.addActionListener(this);
        
   
    }
    @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==boton1){
                this.setVisible(false);
                Menu m1= new Menu();
                m1.setBounds(0, 0, 500, 500);
                m1.setLocationRelativeTo(null);
                m1.setResizable(false);
                m1.setVisible(true);
            }
        }
        
    
}
