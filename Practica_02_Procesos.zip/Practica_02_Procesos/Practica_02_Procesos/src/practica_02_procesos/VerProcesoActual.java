/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import static practica_02_procesos.Practica_02_Procesos.colaProceso;
import static practica_02_procesos.Practica_02_Procesos.procesoEliminado;
import static practica_02_procesos.Practica_02_Procesos.procesoFinalizado;
import static practica_02_procesos.Practica_02_Procesos.ram;
/**
 *
 * @author shens
 */
public class VerProcesoActual extends JFrame implements ActionListener{
    private final JLabel label1;
    private final JLabel label2;
    private final JLabel label3;
    private final JLabel label4;
    private final JLabel label5;
    private final JLabel label6;
    private final JLabel label7;
    private final JLabel label8;
    private final JLabel label9;
    private final JLabel label10;
    private final JLabel label11;
    private final JButton boton1;
    
    
    private final JTextArea ta1;
    private final JScrollPane ts1;
    private final JTextArea ta2;
    private final JScrollPane ts2;
    
    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 20);

    public VerProcesoActual(){
        setLayout(null);
        setTitle("Ver Proceso Actual");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        
        label1 = new JLabel("Ver Proceso Actual", SwingConstants.LEFT);
        label1.setBounds(30, 10, 300, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0,0,0));
        add(label1);
        
        label2 = new JLabel("Nombre: ", SwingConstants.LEFT);
        label2.setBounds(30, 100, 200, 30);
        label2.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label2.setForeground(new Color(0,0,0));
        add(label2);
        
        label3 = new JLabel(colaProceso.get(0).getNameProcess(), SwingConstants.CENTER);
        label3.setBounds(250, 100, 200, 30);
        label3.setFont(font1);
        label3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label3.setForeground(new Color(0,0,0));
        add(label3);
        
        label4 = new JLabel("ID: ", SwingConstants.LEFT);
        label4.setBounds(30, 140, 200, 30);
        label4.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label4.setForeground(new Color(0,0,0));
        add(label4);
        
        label5 = new JLabel(String.valueOf(colaProceso.get(0).getIdProcess()), SwingConstants.CENTER);
        label5.setBounds(250, 140, 200, 30);
        label5.setFont(font1);
        label5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label5.setForeground(new Color(0,0,0));
        add(label5);
        
        label6 = new JLabel("Instrucciones Totales: ", SwingConstants.LEFT);
        label6.setBounds(30, 180, 200, 30);
        label6.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label6.setForeground(new Color(0,0,0));
        add(label6);
        
        label7 = new JLabel(String.valueOf(colaProceso.get(0).getNumInstruccionTotal()), SwingConstants.CENTER);
        label7.setBounds(250, 180, 200, 30);
        label7.setFont(font1);
        label7.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label7.setForeground(new Color(0,0,0));
        add(label7);
        
        label8 = new JLabel("Instrucciones ejecutadas: ", SwingConstants.LEFT);
        label8.setBounds(30, 220, 200, 30);
        label8.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label8.setForeground(new Color(0,0,0));
        add(label8);
        
        label9 = new JLabel(String.valueOf(colaProceso.get(0).getNumInstruccionTotal()-colaProceso.get(0).getNumInstruccion()), SwingConstants.CENTER);
        label9.setBounds(250, 220, 200, 30);
        label9.setFont(font1);
        label9.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label9.setForeground(new Color(0,0,0));
        add(label9);
        
        label10 = new JLabel("Direcciones de memoria asigadas:", SwingConstants.LEFT);
        label10.setBounds(30, 260, 250, 30);
        label10.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label10.setForeground(new Color(0,0,0));
        add(label10);
        
        label11 = new JLabel("Tabla de paginas:", SwingConstants.LEFT);
        label11.setBounds(300, 260, 150, 30);
        label11.setFont(font1);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label11.setForeground(new Color(0,0,0));
        add(label11);
        
        ta1 = new JTextArea();
        ts1 = new JScrollPane(ta1);
        ts1.setBounds(30, 300, 200, 100);
        add(ts1);
        
        ta2 = new JTextArea();
        ts2 = new JScrollPane(ta2);
        ts2.setBounds(300, 300, 150, 100);
        add(ts2);
        
        boton1 = new JButton("Finalizar");
        boton1.setBounds(350, 420, 100, 30);
        boton1.setFont(font1);
        boton1.setBackground(Color.white);
        add(boton1);
        boton1.addActionListener(this);
        
        
        String texto2="";
        for (int j = 0; j < ram.espaciosTotal; j++) {
                if (colaProceso.get(0).getIdProcess() == ram.memoryMatriz[j][1]) {
                    texto2=texto2+String.valueOf(ram.memoryMatriz[j][0])+"   ";
                }
            }
        ta1.setText(texto2);
        
        String texto3="Logica\tFisica\n";
        for(int j=0; j<colaProceso.get(0).getPaginas(); j++){
            texto3=texto3+String.valueOf(colaProceso.get(0).tablaPagina[j][0])+"\t"+String.valueOf(colaProceso.get(0).tablaPagina[j][1])+"\n";
        }
        ta2.setText(texto3);
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            this.setVisible(false);
            Menu m1 = new Menu();
            m1.setBounds(0, 0, 500, 500);
            m1.setLocationRelativeTo(null);
            m1.setResizable(false);
            m1.setVisible(true);

        }
    }
}
