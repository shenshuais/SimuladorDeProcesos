/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_02_procesos;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import static practica_02_procesos.Practica_02_Procesos.ram;

/**
 *
 * @author shens
 */
public class VerEstadoDeLaMemoria extends JFrame implements ActionListener {

    private final JLabel label1;
    private final JTextArea ta1;
    private final JScrollPane ts1;
    private final JButton boton1;
    Font font = new Font("Agency FB", Font.PLAIN, 40);
    Font font1 = new Font("Agency FB", Font.PLAIN, 20);

    public VerEstadoDeLaMemoria() {
        setLayout(null);
        setTitle("Ver Estado De La Memoria");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);

        label1 = new JLabel("Ver Estado De La Memoria", SwingConstants.LEFT);
        label1.setBounds(30, 10, 600, 80);
        label1.setFont(font);
        //label1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label1.setForeground(new Color(0, 0, 0));
        add(label1);

        ta1 = new JTextArea();
        ts1 = new JScrollPane(ta1);
        ts1.setBounds(30, 100, 440, 250);
        add(ts1);
        ram.hacerListaLigada();
        Elemento elementoAux;
        elementoAux = Practica_02_Procesos.ram.listaLigada.get(0);
        String texto1 = "                                      " + elementoAux.elemento[0] + " " + elementoAux.elemento[1] + " " + elementoAux.elemento[2]+"\n";
        if (Practica_02_Procesos.ram.listaLigada.size() > 1) {
            for (int i = 1; i < Practica_02_Procesos.ram.listaLigada.size(); i++) {
                elementoAux = Practica_02_Procesos.ram.listaLigada.get(i);
                texto1 = texto1 + "                             ----->" + elementoAux.elemento[0] + " " + elementoAux.elemento[1] + " " + elementoAux.elemento[2]+"\n";

            }
        }
        ta1.setText(texto1);
        ta1.setFont(font1);
        

        boton1 = new JButton("Finalizar");
        boton1.setBounds(350, 400, 100, 30);
        boton1.setFont(font1);
        boton1.setBackground(Color.white);
        add(boton1);
        boton1.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            this.setVisible(false);
            Menu m1 = new Menu();
            m1.setBounds(0, 0, 500, 500);
            m1.setLocationRelativeTo(null);
            m1.setResizable(false);
            m1.setVisible(true);

        }
    }
}
